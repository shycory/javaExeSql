create trigger TRIGGER_SEAL_INFO
    before update
    on D_SEAL_INFO
    for each row
begin
	 :new.UPD_TIME := sysdate;
end;
/

