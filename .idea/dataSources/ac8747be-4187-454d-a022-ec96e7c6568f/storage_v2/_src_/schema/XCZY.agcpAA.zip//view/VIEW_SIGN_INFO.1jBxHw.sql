create view VIEW_SIGN_INFO as
select t_sign_info.sign_id AS sign_id,t_sign_info.worksheet_id AS worksheet_id,t_sign_info.task_id AS task_id,t_sign_info.task_name AS task_name,t_sign_info.record_id AS record_id,t_sign_info.sign_user AS sign_user,t_sign_info.sign_in_time AS sign_in_time,t_sign_info.sign_place AS sign_place,t_sign_info.sign_out_time AS sign_out_time,t_sign_info.sign_out_place AS sign_out_place,t_sign_info.track_start_time AS track_start_time,t_sign_info.track_end_time AS track_end_time,t_sign_info.remark AS remark,t_sign_info.reg_user AS reg_user,t_sign_info.reg_time AS insert_time,t_sign_info.update_user AS update_user,t_sign_info.update_time AS upt_time 
from t_sign_info
/

