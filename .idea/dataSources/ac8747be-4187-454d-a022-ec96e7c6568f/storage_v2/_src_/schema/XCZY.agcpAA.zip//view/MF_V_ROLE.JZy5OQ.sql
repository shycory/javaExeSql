create view MF_V_ROLE as
select mf_org_role.ROLE_ID AS ROLE_ID,mf_org_role.ROLE_NAME AS ROLE_NAME,mf_org_role.ROLE_DESC AS ROLE_DESC from mf_org_role where (mf_org_role.IS_ROLE_TYPE = 1)
/

