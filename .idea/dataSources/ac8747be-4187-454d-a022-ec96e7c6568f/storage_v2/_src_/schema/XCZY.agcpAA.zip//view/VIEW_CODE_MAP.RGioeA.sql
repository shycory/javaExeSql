create view VIEW_CODE_MAP as
select b_code_map.id AS id,b_code_map.code_type AS code_type,b_code_map.code_value AS code_value,b_code_map.code_name AS code_name,b_code_map.code_desc AS code_desc,b_code_map.lang AS lang,b_code_map.reg_user AS reg_user,b_code_map.reg_time AS insert_time,b_code_map.upd_user AS upd_user,b_code_map.upd_time AS upt_time 
from b_code_map
/

