create view VIEW_WORKSHEET_FILE as
select t_worksheet_file.file_id AS file_id,t_worksheet_file.worksheet_id AS worksheet_id,t_worksheet_file.worksheet_name AS worksheet_name,t_worksheet_file.file_type AS file_type,t_worksheet_file.show_name AS show_name,t_worksheet_file.file_name AS file_name,t_worksheet_file.file_path AS file_path,t_worksheet_file.file_source AS file_source,t_worksheet_file.remark AS remark,t_worksheet_file.file_status AS file_status,t_worksheet_file.reg_user AS reg_user,t_worksheet_file.reg_time AS insert_time,t_worksheet_file.update_user AS update_user,t_worksheet_file.update_time AS upt_time 
from t_worksheet_file
/

