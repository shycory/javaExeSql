create view VIEW_TASK_FILE as
select t_task_file.file_id AS file_id,t_task_file.task_id AS task_id,t_task_file.task_name AS task_name,t_task_file.file_type AS file_type,t_task_file.show_name AS show_name,t_task_file.file_name AS file_name,t_task_file.file_path AS file_path,t_task_file.file_source AS file_source,t_task_file.remark AS remark,t_task_file.file_status AS file_status,t_task_file.reg_user AS reg_user,t_task_file.reg_time AS insert_time,t_task_file.update_user AS update_user,t_task_file.update_time AS upt_time 
from t_task_file
/

