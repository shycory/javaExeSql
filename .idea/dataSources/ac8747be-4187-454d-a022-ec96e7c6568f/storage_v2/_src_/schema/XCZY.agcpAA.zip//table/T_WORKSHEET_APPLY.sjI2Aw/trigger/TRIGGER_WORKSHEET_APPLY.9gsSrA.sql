create trigger TRIGGER_WORKSHEET_APPLY
    before update
    on T_WORKSHEET_APPLY
    for each row
begin
	 :new.update_time := sysdate;
end;
/

