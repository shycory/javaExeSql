create trigger TRIGGER_WORKSHEET_INFO
    before update
    on T_WORKSHEET_INFO
    for each row
begin
	 :new.update_time := sysdate;
end;
/

