create trigger TRIGGER_WORKSHEET_APPLY_USER
    before update
    on T_WORKSHEET_APPLY_USER
    for each row
begin
	 :new.update_time := sysdate;
end;
/

