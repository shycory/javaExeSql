create trigger TRIGGER_SEQ_USER
    before insert
    on USER_TEST_LOG
    for each row
BEGIN
					select SEQ_USER_TEST.nextval into :new.id from dual;
		END;
/

