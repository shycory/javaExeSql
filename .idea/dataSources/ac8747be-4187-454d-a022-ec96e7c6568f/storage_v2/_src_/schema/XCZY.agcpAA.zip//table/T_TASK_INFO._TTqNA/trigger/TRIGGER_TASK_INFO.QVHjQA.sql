create trigger TRIGGER_TASK_INFO
    before update
    on T_TASK_INFO
    for each row
begin
	 :new.update_time := sysdate;
end;
/

