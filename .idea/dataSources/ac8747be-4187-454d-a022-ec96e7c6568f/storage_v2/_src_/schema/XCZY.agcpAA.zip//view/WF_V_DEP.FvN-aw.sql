create view WF_V_DEP as
select mf_org_dep.DEP_ID AS DEP_ID,mf_org_dep.SEQUENCE_ID AS SEQUENCE_ID,mf_org_dep.PARENT_ID AS PARENT_ID,mf_org_dep.DEP_NAME AS DEP_NAME,mf_org_dep.ORG_TYPE AS ORG_TYPE,mf_org_dep.CONTAINER_TYPE AS CONTAINER_TYPE,mf_org_dep.DEP_INDEX AS DEP_INDEX,mf_org_dep.DEP_DESC AS DEP_DESC 
from mf_org_dep where (mf_org_dep.IS_DELETED = 0)
/

